import 'package:flutter/material.dart';
import 'auth_screen.dart';
import 'home_screen.dart';
import 'voice_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Energy Management App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/auth', // Đặt route mặc định là /auth
      routes: {
        '/auth': (context) => const AuthScreen(), // Đổi '/' thành '/auth'
        '/home': (context) => const HomeScreen(),
        '/voice': (context) => const VoiceScreen(),
      },
    );
  }
}
