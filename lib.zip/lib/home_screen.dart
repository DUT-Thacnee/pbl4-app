import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedDevice = 'Home'; // Thiết bị mặc định

  void _logout() {
    Navigator.pushReplacementNamed(context, '/auth'); // Điều hướng về màn hình đăng nhập
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Smart Energy Management',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF3A8DFF), Color(0xFF6AB4FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          DropdownButton<String>(
            value: selectedDevice,
            dropdownColor: Colors.blueAccent,
            icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
            items: <String>['Home', 'Device 1', 'Device 2', 'Device 3']
                .map((String device) {
              return DropdownMenuItem<String>(
                value: device,
                child: Text(device, style: const TextStyle(color: Colors.white)),
              );
            }).toList(),
            onChanged: (String? newDevice) {
              if (newDevice != null) {
                setState(() {
                  selectedDevice = newDevice;
                });
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomeScreen(),
                  ),
                );
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: _logout, // Gọi hàm _logout khi nhấn vào nút
          ),
        ],
      ),
      body: Column(
        children: [
          // Input display boxes
          Row(
            children: [
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text('Input 1: ... for $selectedDevice'),
                ),
              ),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text('Input 2: ... for $selectedDevice'),
                ),
              ),
            ],
          ),
          // Statistics table
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(child: Text('Statistics Table for $selectedDevice')),
            ),
          ),
          // Microphone button
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pushNamed(context, '/voice');
            },
            icon: const Icon(Icons.mic),
            label: const Text('Voice Input'),
          ),
        ],
      ),
    );
  }
}
